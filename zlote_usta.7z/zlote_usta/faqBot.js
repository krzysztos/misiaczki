function askBot(element) {
    element.classList.remove("question");
    element.classList.add("questionAnimated");
}

const botID = document.getElementById('bot');
const questionID = document.getElementById('question');
botID.addEventListener('click', function(){
    askBot(questionID, botID);
}, false);
