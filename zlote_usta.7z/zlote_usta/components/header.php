<!-- NAGŁÓWEK - Particles -->

<section class="header" style="position: relative;">

<!-- particles.js container -->
<div id="particles-js"></div>

<div style="position: absolute; top: 18%; text-align: center; width: 100%; padding-right: 50px; background: rgba(0,0,0,0.4); padding-bottom: 100px;">

  <img class="w-25" src="./img/lips2.png" alt="logo" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <h1 class="l-s-2 rf-2" style="font-size: 50px;">Złote usta</h1>
</div>

<div id="arrow_down"><img style="width: 70px;" src="./img/arrow_down.png" alt="arrow down"></div>
<script src="js/scroll.js"></script>

<!-- scripts -->
<script src="./particles/particles.js"></script>
<script src="js/app.js"></script>

<script src="js/lib/stats.js"></script>
<script>
  var count_particles, stats, update;
  stats = new Stats;
  stats.setMode(2);
  stats.domElement.style.position = 'absolute';
  stats.domElement.style.left = '0px';
  stats.domElement.style.top = '0px';
  document.body.appendChild(stats.domElement);
  count_particles = document.querySelector('.js-count-particles');
  update = function() {
    stats.begin();
    stats.end();
    if (window.pJSDom[0].pJS.particles && window.pJSDom[0].pJS.particles.array) {
    //   count_particles.innerText = window.pJSDom[0].pJS.particles.array.length;
    }
    requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
</script>

</section>

<div id="under-header"></div>