<!-- MENU NA GÓRZE -->    
<nav class="navbar navbar-inverse bg-black">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                </button>
                <a class="navbar-brand" href="./"><span class="glyphicon glyphicon-fire"></span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="./"><span class="glyphicon glyphicon-home"></span> Strona główna</a></li>
                    <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-th-list"></span> Konkursy <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="zlote_usta.html">Złote Usta</a></li>
                        <li><a href="#">Konkurs 2</a></li>
                        <li><a href="#">Konkurs 3</a></li>
                    </ul>
                    </li>
                    <li><a href="#"><span class="glyphicon glyphicon-plus"></span> Dodaj konkurs</a></li>
                    <li><a href="contact.php"><span class="glyphicon glyphicon-envelope"></span> Kontakt</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Zaloguj się</a></li>
                </ul>
            </div>
        </div>
    </nav>