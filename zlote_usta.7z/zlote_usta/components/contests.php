<!-- KONKURSY -->

<div class="jumbotron text-center">
        <h1>Wszystkie konkursy biblioteczne</h1>
        <p>Weź udział w konkursie lub zaproponuj pomysł na własny</p > 
    </div>
    <hr>
    <br>
    <br>

<div class="container-fluid main">
        <div class="row">
            <div class="col-sm-4">
                <a href='zlote_usta.html' class='contestLink'>Złote usta</a>
                <img class="w-100" src="img/lips2.png" alt="Usta" class="img-thumbnail">
                <p class='description'>Wykaż się umiejętnościami lingwistycznymi i zaimponuj jury</p>
            </div>
            <div class='forPhones'>
                <br>
                <br>
                <hr>
            </div>
            <div class="col-sm-4">
                <a href='zlote_usta.html' class='contestLink'>Złote usta</a>
                <img class="w-100" src="img/lips2.png" alt="Usta" class="img-thumbnail">
                <p class='description'>Wykaż się umiejętnościami lingwistycznymi i zaimponuj jury</p>
            </div>
            <div class='forPhones'>
                <br>
                <br>
                <hr>
            </div>
            <div class="col-sm-4">
                <a href='zlote_usta.html' class='contestLink'>Złote usta</a>
                <img class="w-100" src="img/lips2.png" alt="Usta" class="img-thumbnail">
                <p class='description'>Wykaż się umiejętnościami lingwistycznymi i zaimponuj jury</p>
            </div>
        </div>
    </div>