 <!-- STOPKA -->
 <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <h4 class="siteDescription">Nie znalazłeś satysfakcjonującego Cię konkursu ?</h4>
                    <p>Pamiętaj, że zawsze masz możliwość zgłoszenia swojego pomysłu na naszej stronie !</p>
                </div>
                <div class="col-sm-4">
                    <span class="bottomLinks">         
                        <a href="#">Głosuj</a>
                        <a href="#">Dodaj konkurs</a>
                        <a href="./contact.php">Kontakt</a>
                        <a href="#">Wszystkie nasze konkursy</a>
                    </span>            
                </div>
                <div class="col-sm-4">
                    <div class='botAndQuestions'>
                        <h4 class="botTitle">Zadaj pytanie botu</h4>
                        <img class="img-responsive img-responsive2" src="img/bot.png" alt="Bot" class="img-thumbnail" id='bot'>
                        <div id="question" class='question'>Jak mogę wziąć udział w konkursie ?</div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-center">Wszystkie konkursy biblioteczne - Stasiek Maniek Kobiałka</div>
        </div>        
    </footer>

    <footer class="last-footer l-s-1">
        <span class="c-purple">&copy;</span> 2020 Opracowane przez uczniów <a class="c-purple last-footer-a" href="https://tm1.edu.pl/" target="_blank">ZSLiT</a> nr 1
    </footer>
