<?php

function import($path)
{
    include('./'.$path.'.php');
}