document.getElementById('arrow_down').addEventListener("click", function() {

    document.getElementById("under-header").scrollIntoView();

});