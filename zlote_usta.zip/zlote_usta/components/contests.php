<!-- KONKURSY -->
<div class="container-fluid main">
        <div class="row">
            <div class="col-sm-4">
                <a href='zlote_usta.html' class='contestLink'>Złote usta</a>
                <img class="img-responsive" src="img/lips2.png" alt="Usta" class="img-thumbnail">
                <p class='description'>Wykaż się umiejętnościami lingwistycznymi i zaimponuj jury</p>
            </div>
            <div class='forPhones'>
                <br>
                <br>
                <hr>
            </div>
            <div class="col-sm-4">
                <a href='zlote_usta.html' class='contestLink'>Złote usta</a>
                <img class="img-responsive" src="img/lips2.png" alt="Usta" class="img-thumbnail">
                <p class='description'>Wykaż się umiejętnościami lingwistycznymi i zaimponuj jury</p>
            </div>
            <div class='forPhones'>
                <br>
                <br>
                <hr>
            </div>
            <div class="col-sm-4">
                <a href='zlote_usta.html' class='contestLink'>Złote usta</a>
                <img class="img-responsive" src="img/lips2.png" alt="Usta" class="img-thumbnail">
                <p class='description'>Wykaż się umiejętnościami lingwistycznymi i zaimponuj jury</p>
            </div>
        </div>
    </div>