<!-- NAGŁÓWEK -->
<div class="jumbotron text-center">
        <h1>Wszystkie konkursy biblioteczne</h1>
        <p>Weź udział w konkursie lub zaproponuj pomysł na własny</p > 
    </div>
    <hr>
    <br>
    <br>